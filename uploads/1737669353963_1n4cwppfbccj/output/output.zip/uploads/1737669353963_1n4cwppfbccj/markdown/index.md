# Reference Guide

## AttendanceRostering

### [AttendanceUtilities](attendancerostering\AttendanceUtilities.md)

shared utilities used by features in the attendance tracking business unit. Includes functions for creating test data, getting daily rosters for businesses, 
performing checkin/checkout operations and more. 
NOTE: Currenly set to without sharing as the profile for the community user does not have full access to the Enrollment__c records that are required to operate this class.